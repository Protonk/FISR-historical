utils::globalVariables(c(
  ".", "A", "A_rank", "Avg_Error", "B", "B_rank", "Bottom", "Depth",
  "Error", "Error_Type", "Left", "Location", "M", "Magic", "Max_Error",
  "Midpoint", "N", "N_type", "Range_Max", "Range_Min", "Range_Min_large",
  "Range_Min_small", "Rarity", "Variance", "Width", "after_one",
  "average_magic", "bin", "closest_target", "cluster", "count",
  "delta_error", "delta_magic", "error", "error1", "error2",
  "error_after", "error_before", "error_scaled", "fill_color", "initial",
  "input", "iter_rank", "iters", "magic", "matched_avg_error",
  "mean_error", "mean_magic", "method", "min_magic", "max_magic",
  "max_error", "pair", "reference", "relErrGuess", "relErrNR",
  "relative_error", "relative_error_after", "relative_error_before",
  "statistic", "x", "xmax", "xmin", "y_end", "y_start", "err_rank",
  "improvement", "M_index", ".blinncomp_labels", ".create_geom_points",
  ".deconstruction_palettes", ".mc_annotate",
  "ymax", "ymin"
))
