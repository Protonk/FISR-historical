library(testthat)
library(visualfrsr)

test_check("visualfrsr")
